#include "syscall.h"

int main() {
    int i = 1 / 0;
    exit(0);
}
